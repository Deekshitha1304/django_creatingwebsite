from django.shortcuts import render

def home(request):
    return render(request, 'home.html')
def about(request):
    context = {}
    if request.method == 'POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        school_id = request.POST.get('school_id')
        student_class = request.POST.get('student_class')

        # Add data to context for thank-you message
        context['submitted'] = True
        context['name'] = name

    return render(request, 'about.html', context)